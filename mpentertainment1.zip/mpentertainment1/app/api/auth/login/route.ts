import { NextResponse } from "next/server";
export async function POST() {
  // mock login
  return NextResponse.json({ ok: true, user: { id: "u1", role: "user" } });
}
