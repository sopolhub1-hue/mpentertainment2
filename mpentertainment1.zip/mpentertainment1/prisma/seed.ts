/**
 * Seed placeholder (no prisma client generated in mock build).
 * When you enable Prisma client, you can implement real seeding here.
 */
console.log("Seed script placeholder. Configure DATABASE_URL + prisma client to seed real data.");
