/**
 * DB placeholder.
 * Future: initialize Prisma client here.
 */
export const db = {
  ready: false,
};
